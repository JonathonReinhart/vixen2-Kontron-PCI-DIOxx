// DIODlg.h : header file
//

#if !defined(AFX_DIODLG_H__5B999247_4D71_11D2_B760_0000C000224F__INCLUDED_)
#define AFX_DIODLG_H__5B999247_4D71_11D2_B760_0000C000224F__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

/////////////////////////////////////////////////////////////////////////////
// CDIODlg dialog

class CDIODlg : public CDialog
{
// Construction
public:
	CDIODlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CDIODlg)
	enum { IDD = IDD_DIO_DIALOG };
	CStatic	m_IsaStatic;
	CEdit	m_IsaEditCtrl;
	CEdit	m_StatusControl;
	CButton	m_TimerButton;
	CComboBox	m_AddressCombo;
	CString	m_CardName;
	CString	m_AddressSelection;
	CString	m_InputA;
	CString	m_InputB;
	CString	m_OutputA;
	CString	m_StatusEdit;
	CString	m_IsaEdit;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDIODlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
	void FindCards(void);
	void UpdateDriverRegistry(void);
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CDIODlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnBeginButton();
	afx_msg void OnExitButton();
	afx_msg void OnAddressComboChange();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnShowWindow(BOOL bShow, UINT nStatus);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DIODLG_H__5B999247_4D71_11D2_B760_0000C000224F__INCLUDED_)
